import './src/style/global.css';
import '@fontsource/lora/700.css';
import '@fontsource/lora/400-italic.css';
import '@fontsource/archivo/700.css';
import '@fontsource/archivo/400-italic.css';
import '@fontsource/archivo/400.css';
import 'react-multi-carousel/lib/styles.css';
